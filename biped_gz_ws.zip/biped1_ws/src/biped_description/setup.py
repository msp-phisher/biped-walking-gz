from setuptools import setup, find_packages
import os
from glob import glob

package_name = 'biped_description'

setup(
    name=package_name,
    version='0.0.1',

    # IMPORTANT: this must find biped_description + submodules
    packages=find_packages(exclude=['test']),

    data_files=[
        # ament index
        ('share/ament_index/resource_index/packages',
         ['resource/' + package_name]),

        # package.xml
        ('share/' + package_name, ['package.xml']),

        # launch files
        (os.path.join('share', package_name, 'launch'),
         glob('launch/*.py')),

        # URDF / XACRO
        (os.path.join('share', package_name, 'urdf'),
         glob('urdf/*.urdf') + glob('urdf/*.xacro')),

        # controller config
        (os.path.join('share', package_name, 'config'),
         glob('config/*.yaml')),
    ],

    install_requires=['setuptools'],
    zip_safe=True,

    maintainer='manoja',
    maintainer_email='manoja@todo.todo',
    description='Biped robot description and walking controller',
    license='Apache-2.0',

    entry_points={
        'console_scripts': [
            'walking_controller = biped_description.scripts.walking_controller:main',
        ],
    },
)

